package com.example.demo;

import org.junit.jupiter.api.Test;

import cn.renlm.plugins.MyGeneratorUtil;

/**
 * 代码生成
 * 
 * @author RenLiMing(任黎明)
 *
 */
public class MyGeneratorTest {

	@Test
	public void run() {
		MyGeneratorUtil.run("MyGenerator.xml");
	}

}
